Чтобы установить пакет, выполните команду, находясь в домашней директории:
	python3 -m pip install --user dist/code-0.1.0-py3-none-any.whl

# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['package_welcome']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do-something = package_welcome.welcomee:main']}

setup_kwargs = {
    'name': 'package-welcome',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Чтобы установить пакет, выполните команду, находясь в домашней директории:\n\tpython3 -m pip install --user dist/code-0.1.0-py3-none-any.whl\n',
    'author': 'Всеволод Деменьшин',
    'author_email': 'vdexpert11@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
